# Indian Taash — Design Package

The look, feel and interaction design of the app, collected in one place: the royal-court visual
system, typography, components, card and board artwork, motion, sound, icons and the user flow.

## Folder map
| Folder | What is inside |
|---|---|
| `source/ui/theme` | Palette (`Color.kt`), type scale (`Type.kt`), shapes, spacing, radii, elevation — the design tokens |
| `source/ui/components` (+ `royal/`) | RoyalPanel, RoyalButton, plaques, controls, text field, states, game tile, ornamental divider, bottom navigation, antique wood table |
| `source/ui/cards` | Playing-card renderer: antique ivory faces, royal portraits, suit pips, card backs, fan and stack layouts |
| `source/ui/board`, `source/ui/snakes` | Ludo and Moksha Patam (Snakes & Ladders) boards, 3D die, token motion, yard plaques, layout |
| `source/ui/thumbnails` | The game-tile pictures drawn in code |
| `source/ui/splash`, `chrome`, `background`, `motion` | Splash screen, top bar, heritage backgrounds, motion and orientation preferences |
| `source/ui/*` (other) | Every screen: login, language, profile, avatars, friends, lobby, notifications, pokes, settings, membership, rules |
| `source/navigation`, `source/domain` | The four tabs and routes; the board-game catalogue entry |
| `assets/fonts` | Cinzel (display) and Marcellus (titles), bundled locally |
| `assets/icons` | Launcher icon in every density, adaptive icon layers |
| `assets/images` | Splash artwork and launcher foreground |
| `assets/audio` | The 35 sound effects (card, dice, tokens, UI, victory and so on) |
| `assets/values` | `colors.xml`, themes, English and Hindi strings (the eight languages share the same keys) |
| `graphics` | Store icon (512), feature graphic (1024x500), the three-font Hindi typography comparison |
| `docs` | `DESIGN_DECISIONS.md` (every approved design element), third-party notices |

## The royal-court visual system
**Mood:** an Indian village courtyard turned royal darbar — carved dark wood, antique brass and
bevelled gold, deep maroon, saffron, ivory and parchment. Everything is drawn in code (gradients,
bevels, corner caps, grain) rather than from image files, so it scales to every screen.

**Palette tokens (`Color.kt`)**
| Role | Colours |
|---|---|
| Wood panels | `#24160C` dark, `#3A2515` mid, `#4A301B` light; base `#1B110A` |
| Gold | bevel light `#E8C77A`, bevel dark `#8A6A2A`, glow `#F5C542`, brass `#C9A24B` / `#7A5A22`, antique `#B4822E` |
| Text | parchment `#EADCBF`, dim `#BFA985`, ink `#2A1E16` on ivory |
| Crimson button | `#9A2E1E` to `#5A150C` |
| Steel button | `#4E5664` to `#232830` |
| Heritage | maroon `#6B1421`, saffron `#E08A2C`, terracotta `#B5613C`, deep green `#3D4F32`, indigo `#2E3A5C`, ivory `#FBF3E3` |
| Card faces | ivory `#F3E4C2`, red ink `#9B1C28`, black ink `#1F1812` |
| Game-tile backdrops | crimson, indigo, emerald, saffron radial gradients |

**Shapes and spacing:** radii 4 / 8 / 12 / 16 / 24 dp; spacing 8 / 16 / 24 / 32 dp; cards 10 dp corners.

**Typography (`Type.kt`):** Cinzel Bold for display and panel titles (carved-inscription look,
letter-spaced); Marcellus for titles and buttons; platform serif for body. Hindi and other Indic
scripts currently fall back to the phone's Noto fonts. A Mukta / Hind / Noto Sans Devanagari
comparison is in `graphics/` awaiting a decision.

**Signature components:** the RoyalPanel (carved wood, double gold frame, corner caps, centred
title with a fading gold rule); crimson and steel plaque buttons; orb switches; segmented controls;
skeleton, empty, error and offline states; gold-framed game portraits above a crimson name plaque.

## Cards and boards
- **Cards:** antique ivory faces with royal portraits, suit pips and ornamental backs; fans, rows and stacks.
- **Ludo:** flat printed board (red `#FF1018`, green `#25E500`, yellow `#FFF500`, blue `#55C7F5`,
  black lines), yards with nests, a pearl-finish goti drawn per colour, a 3D die.
- **Moksha Patam:** ivory 10x10 board in a gold vine border, creeper ladders, serpents with lotus heads.
- **Table layout:** boards take 70 percent of the screen in portrait and 80 percent in landscape; dice, names and controls use the rest.

## Motion and sound
Die spins and settles (gold flash on a six); tokens glide along an arc with a trail; captured
tokens shrink home; safe squares shine; page shiver and banner for pokes. A switch in Settings
(and the phone's own setting) reduces motion to simple fades or snaps. 35 sound effects cover
cards, dice, tokens, ladders and serpents, UI taps and fanfares.

## Screen flow
Four bottom tabs: **Cards** (the games grid), **Entertainment** (Ludo, Moksha Patam), **Friends**,
**Settings**. A top bar carries the "Remove ads" tab (hidden while there are no ads), notification
bell and account tab. Each game opens an introduction and setup page (mode, players, difficulty,
house rules), then the table, with a lobby for online and nearby play. Splash: the Taash artwork for
four seconds, with no system icon. Orientation is selectable in Settings.

## Notes
- The heritage background scenes are gradient placeholders; real photography was never supplied.
- The 20 avatar illustrations are not in the app yet: the picker shows numbered discs until `avatar_01_...` to `avatar_20_...` PNGs are added to `res/drawable`.
- Fonts are under the SIL Open Font License; see `docs/THIRD_PARTY_NOTICES.md`.
